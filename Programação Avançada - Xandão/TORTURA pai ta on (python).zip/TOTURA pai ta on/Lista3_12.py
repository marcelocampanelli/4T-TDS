n = int(input("digite um numero de 1 a 10: "))
cont = 1

while cont <= 10:
    tab = n * cont
    print(n, "X", cont, "=", tab)
    cont = cont + 1
