
for i in range(1, 21):
    print(i)

print(list(range(1, 21)))
