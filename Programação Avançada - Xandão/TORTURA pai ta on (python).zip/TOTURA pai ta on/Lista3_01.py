
nota = float(input("Digite uma nota entre zero e 10: "))

while nota > 10 or nota < 0:
    nota = float(input("Informe um valor válido: "))
