numero = int(input("\nDigite um número: "))

if numero % 2 == 0 and numero != 2:
    print("não primo")
else:
    print("primo")
