

for i in range(3, 50, 2):
    print(i)

print(list(range(3, 50, 2)))
