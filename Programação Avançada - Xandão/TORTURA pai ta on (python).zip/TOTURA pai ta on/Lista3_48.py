numero = input("Digite um número: ")
print("Número invertido: ", numero[:: -1])
